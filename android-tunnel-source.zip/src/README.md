# Android Tunnel

原生 Kotlin Android 工程（arm64）。fix3 增加了组件安装与 SHA-256 校验、服务配置生成、受限 root 命令、进程生命周期、TCP 对端探测和直连/EasyTier/应急管理通道选择。域名、Token、所有 peer 密钥、VPS 地址、证书路径、手机型号和 Android 版本仍需由使用方配置并待实机联调；源码不含真实凭据。

## 本机验证

本轮 Kotlin 2.0.21 主源码编译成功，18 项 JVM 单测通过。Gradle `testReleaseUnitTest` 因沙箱禁止 Gradle daemon 监听 socket 而未能启动；没有执行 Android Gradle 完整构建、APK 打包或真机测试。操作方须在沙箱外使用 JDK 21、Android SDK 35、Gradle 8.11.1 重新运行：

```sh
cd src
export ANDROID_HOME=/data/android-sdk JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
./gradlew testReleaseUnitTest assembleRelease
```

签名仍从 `ANDROID_TUNNEL_KEYSTORE`、`ANDROID_TUNNEL_STORE_PASSWORD`、`ANDROID_TUNNEL_KEY_ALIAS`、`ANDROID_TUNNEL_KEY_PASSWORD` 读取。不要将 keystore 或密码加入源码归档。

## 运行配置

设置页中的 Cloudflare Token、私钥、UUID、密码和网络密钥通过 Android Keystore 支持的 `SecretStore` 加密保存。运行配置在私有目录中生成，权限仅限应用所有者；进程停止时删除。五个二进制先解到应用私有目录并按 `assets/arm64/SHA256SUMS` 校验，再复制到 `/data/local/tmp/android-tunnel/` 供 root 启动。

启动前必须提供 AmneziaWG peer 私钥/公钥、Endpoint、AllowedIPs、本机隧道地址，VLESS Reality 参数、Hysteria2 证书/私钥路径、EasyTier 网络名/密钥与自建 relay、探测地址、Tunnel Token 和 wstunnel 管理地址。端口初次显示时随机选取 20000–60000 的高位端口。没有完整配置或任一组件校验失败时不会启动链路，并会显示具体缺失项。

root 命令通过 `RootController` 集中限制；执行包括接口地址/路由、MTU 1280、IPv6 INPUT/FORWARD 放行及组件启停。主链路探测失败后尝试 EasyTier，再失败才启 cloudflared 与只转发本机 SSH 管理端口的 wstunnel。状态延迟来自 TCP connect 实测；未收到对端响应时不显示延迟。

## 实机依赖与限制

- 交付的五个 arm64 二进制摘要来自 `app/src/main/assets/arm64/SHA256SUMS`；源码 zip 不含二进制，可按 `scripts/fetch-upstream.sh` 和 `upstream/SHA256SUMS.lock` 复现。
- AmneziaWG 配置应用依赖设备 root 环境提供兼容的 `awg setconf` 命令；该管理工具不在五个已交付二进制中。接口、SELinux、`/dev/net/tun`、iproute2 和 ip6tables 都需要实机验证，失败会回滚并报错。
- Hysteria2 需要用户提供有效证书文件。对端格式、EasyTier CLI 参数、cloudflared/wstunnel 远端设置与 Android 后台行为均未真机验证。
- 优选 IP 输入目前只保存并显示配置值；cloudflared 实际边缘节点选择/固定及实测边缘延迟尚未实现，界面不会把配置值伪报为实际节点。
- TCP 探测只测配置端点的 TCP 建连往返时间，不验证应用层身份或隧道内数据传输。状态仅表示端口收到 TCP 响应，不等同于完整业务链路验收。
- fix2 的 APK（若在 `deliverables/` 中）不是本轮源码构建产物，不包含 fix3 改动。当前源码不能据此 APK 安装验证。

详细结果见 `../deliverables/ANDROID_REPORT.md` 和 `../deliverables/ANDROID_TEST_REPORT.md`。
